package edmt.dev.androidmultichoicesquiz.Interface;

import android.view.View;

public interface IRecyclerHelperClick {
    void onClick(View view, int position);
}
